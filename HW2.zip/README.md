# Symbolic-Regression
Uses genetic programming to solve a symbolic regression problem. To run:

python darwin_v2.py
